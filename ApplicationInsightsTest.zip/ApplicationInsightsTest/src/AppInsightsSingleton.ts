import {
  ApplicationInsights,
  ITelemetryItem,
} from "@microsoft/applicationinsights-web";
import { PageContext } from "@microsoft/sp-page-context";

export interface CustomTelemetryData {
  siteUrl?: string;
  userLogin?: string;
}

let appInsights: ApplicationInsights | undefined;

export function getAppInsights(): ApplicationInsights {
  if (!appInsights) {
    appInsights = new ApplicationInsights({
      config: {
        connectionString:
          "InstrumentationKey=81a80969-b663-465e-ba05-3dc55d28db25;IngestionEndpoint=https://westus2-2.in.applicationinsights.azure.com/;LiveEndpoint=https://westus2.livediagnostics.monitor.azure.com/;ApplicationId=d1218ca2-abdc-4360-9272-f0c49942f96b",
        disableFetchTracking: false,
      },
    });
    appInsights.loadAppInsights();
  }

  return appInsights;
}

/**
 * Adds page-context related telemetry (siteUrl, userLogin) safely at runtime.
 */
export function addCustomTelemetry(pageContext?: PageContext): void {
  if (!appInsights) return;

  appInsights.addTelemetryInitializer((envelope: ITelemetryItem) => {
    envelope.tags = envelope.tags || {};
    envelope.tags["ai.cloud.role"] = "SPFxWebPart";
    if (!pageContext) return;
    (envelope.data as any).properties = {
      ...((envelope.data as any).properties ?? {}),
      siteUrl: pageContext.site.absoluteUrl,
      userLogin: pageContext.user.loginName,
    };
  });
}
