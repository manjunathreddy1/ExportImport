import * as React from "react";
//import styles from './ApplicationInsightsWebpart.module.scss';
import type { IApplicationInsightsWebpartProps } from "./IApplicationInsightsWebpartProps";
//import { escape } from '@microsoft/sp-lodash-subset';
import { MSGraphClientV3 } from "@microsoft/sp-http";
import { getAppInsights } from "../../../AppInsightsSingleton";

export default class ApplicationInsightsWebpart extends React.Component<IApplicationInsightsWebpartProps> {
  private appInsights = getAppInsights();
  private async fetchUserProfile(): Promise<void> {
    try {
      const graphClient: MSGraphClientV3 =
        await this.props.context.msGraphClientFactory.getClient("3");

      const user = await graphClient.api("/me").get();

      this.setState({ displayName: user.displayName });
      this.appInsights.trackTrace({
        message: "fetchUserProfile completed",
        severityLevel: 1,
        properties: {
          functionName: "fetchUserProfile",
          webPart: this.props.context.manifest.alias,
          siteUrl: this.props.context.pageContext.site.absoluteUrl,
        },
      });
    } catch (err) {
      console.error("Graph API call failed", err);
      this.setState({ error: "Failed to load user profile" });
      this.appInsights.trackException({
        exception: err as Error,
        severityLevel: 3,
        properties: {
          webPart: this.props.context.manifest.alias,
          siteUrl: this.props.context.pageContext.site.absoluteUrl,
          userLogin: this.props.context.pageContext.user.loginName,
        },
      });
    }
  }
  componentDidMount() {
    this.fetchUserProfile();
  }
  public render(): React.ReactElement<IApplicationInsightsWebpartProps> {
    return <>Loaded</>;
  }
}
