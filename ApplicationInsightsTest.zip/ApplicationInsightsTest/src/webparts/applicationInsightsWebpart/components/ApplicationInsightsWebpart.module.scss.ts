
require("./ApplicationInsightsWebpart.module.css");
const styles = {
  applicationInsightsWebpart: 'applicationInsightsWebpart_c58bdc98',
  teams: 'teams_c58bdc98',
  welcome: 'welcome_c58bdc98',
  welcomeImage: 'welcomeImage_c58bdc98',
  links: 'links_c58bdc98'
};

export default styles;
