import * as React from "react";
import type { IApplicationInsightsWebpartProps } from "./IApplicationInsightsWebpartProps";
export default class ApplicationInsightsWebpart extends React.Component<IApplicationInsightsWebpartProps> {
    private appInsights;
    private fetchUserProfile;
    componentDidMount(): void;
    render(): React.ReactElement<IApplicationInsightsWebpartProps>;
}
//# sourceMappingURL=ApplicationInsightsWebpart.d.ts.map