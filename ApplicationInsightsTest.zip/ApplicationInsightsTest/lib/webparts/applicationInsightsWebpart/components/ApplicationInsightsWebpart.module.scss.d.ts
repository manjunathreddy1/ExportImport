declare const styles: {
    applicationInsightsWebpart: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=ApplicationInsightsWebpart.module.scss.d.ts.map