import { ApplicationInsights } from "@microsoft/applicationinsights-web";
import { PageContext } from "@microsoft/sp-page-context";
export interface CustomTelemetryData {
    siteUrl?: string;
    userLogin?: string;
}
export declare function getAppInsights(): ApplicationInsights;
/**
 * Adds page-context related telemetry (siteUrl, userLogin) safely at runtime.
 */
export declare function addCustomTelemetry(pageContext?: PageContext): void;
//# sourceMappingURL=AppInsightsSingleton.d.ts.map